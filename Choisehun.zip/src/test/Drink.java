package test;

public class Drink {
	
	
	public static void run() {
		
	yy:while(true) {
				
		Kiosk.p1.info();
		Kiosk.p2.info();
		Kiosk.p3.info();
		
		System.out.println("================================================");
		System.out.println("[1.아이스 아메리카노 2. 아메리카노 3. 카페라떼 x. 이전 메뉴 이동]");
		System.out.println("================================================");
		
		Kiosk.cmd = Kiosk.sc.next();
		
		
		switch(Kiosk.cmd) {
		
		
		case "1":
			System.out.println("아이스 아메리카노 선택");
			Product x = new Product("아이스 아메리카노", 2000);
			Kiosk.basket1.add(x);
			System.out.println("");
			break;
			
		case "2":
			System.out.println("아메리카노 선택");
			Product y = new Product("아메리카노", 1500);
			System.out.println("");
			Kiosk.basket2.add(y);
			break;
			
		case "3":
			System.out.println("카페라떼 선택");
			Product d = new Product("카페라떼", 2000);
			System.out.println("");
			Kiosk.basket3.add(d);
			break;
			
		case "x":
			System.out.println("이전 메뉴 이동");
			System.out.println("");
			break yy;
			
		}
			}//while
	}
		
	


}