package test;

import java.util.ArrayList;
import java.util.Scanner;



public class Kiosk {
	public static ArrayList<Product> basket1 = new ArrayList<Product>();
	public static ArrayList<Product> basket2 = new ArrayList<Product>();
	public static ArrayList<Product> basket3 = new ArrayList<Product>();
	public static ArrayList<Product> basket4 = new ArrayList<Product>();
	public static ArrayList<Product> basket5 = new ArrayList<Product>();
	public static ArrayList<Product> basket6 = new ArrayList<Product>();
	
	
	public static Scanner sc = new Scanner(System.in);
	
	public static Product p1 = new Product("아이스 아메리카노" ,1500);
	public static Product p2 = new Product("아메리카노" ,1000);
	public static Product p3 = new Product("카페라떼" ,2000);
	
	public static Product p4 = new Product("케이크" ,5500);
	public static Product p5 = new Product("마카롱" ,6000);
	public static Product p6 = new Product("바나나" ,2500);
	
	
	public static String cmd;
	
	
	
	void run() {
		xx:while(true) {
			System.out.println("[1.음료 선택 2. 디저트 선택 x.프로그램 종료]");
			cmd=sc.next();
			switch(cmd) {
			case "1":
				Drink.run();
				break;
				
			case "2":
				Dessert.run();
				break;
				
			case "x":
				System.out.println("메뉴 선택 종료");
				System.out.println("");
				
				int sum =0;
				
				
				int sum1 =0;
				int sum2 =0;
				int sum3 =0;
				int sum4 =0;
				int sum5 =0;
				int sum6 =0;
				
				
				
				for(int i=0; i<basket1.size(); i++) { //가격
					sum1 = sum1+basket1.get(i).price;
				}
				
				for(int i=0; i<basket2.size(); i++) {
					sum2 = sum2+basket2.get(i).price;
				}
				
				
				for(int i=0; i<basket3.size(); i++) {
					sum3 = sum3+basket3.get(i).price;
				}
				
				
				for(int i=0; i<basket4.size(); i++) {
					sum4 = sum4+basket4.get(i).price;
				}
				
				
				for(int i=0; i<basket5.size(); i++) {
					sum5 = sum5+basket5.get(i).price;
				}
				
				
				for(int i=0; i<basket6.size(); i++) {
					sum6 = sum6+basket6.get(i).price;
				}
				
				
			
				
				
						
				
				
				int count1 = basket1.size();
				int count2 = basket2.size();
				int count3 = basket3.size();
				int count4 = basket4.size();
				int count5 = basket5.size();
				int count6 = basket6.size();
				
				int countsum = count1+count2+count3+count4+count5+count6;
				
			
				if(count1>0) { //선택된 품목 갯수만 출력
					System.out.println( p1.name + " : " + count1 +"개 선택 가격은 : " + sum1);
					System.out.println("");
					}else {
						
					}
				
				if(count2>0) {
					System.out.println( p2.name + " : " + count2 +"개 선택 가격은 : " + sum2);
					System.out.println("");
					}else {
						
					}
				
				if(count3>0) {
					System.out.println( p3.name + " : " + count3 +"개 선택 가격은 : " + sum3);
					System.out.println("");
					}else {
						
					}
				
				if(count4>0) {
					System.out.println( p4.name + " : " + count4 +"개 선택 가격은 : " + sum4);
					System.out.println("");
					}else {
						
					}
				
				if(count5>0) {
					System.out.println( p5.name + " : " + count5 +"개 선택 가격은 : " + sum5);
					System.out.println("");
					}else {
						
					}
				
				if(count6>0) {
					System.out.println( p6.name + " : " + count6 +"개 선택 가격은 : " + sum6);
					System.out.println("");
					}else {
						
					}
				
				System.out.println("===========================");
				System.out.println("총주문량 : " + countsum +"개");
				
				
				
				
				
				
			
				sum= sum1+sum2+sum3+sum4+sum5+sum6;
				System.out.println("===========================");
				System.out.println("계산금액 : " + sum +"원");
				System.out.println("===========================");

				
			
				break xx;
		
				
				
				
			}
			
			
			
			
		}//while
		
	}
}
