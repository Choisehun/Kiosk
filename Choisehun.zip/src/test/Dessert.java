package test;

public class Dessert {
	
	
	public static void run() {
		
	yy:while(true) {
				
		Kiosk.p4.info();
		Kiosk.p5.info();
		Kiosk.p6.info();
		
		System.out.println("================================================");
		System.out.println("[1.케이크 2. 마카롱 3. 바나나 x. 이전 메뉴 이동]");
		System.out.println("================================================");
		Kiosk.cmd = Kiosk.sc.next();
		
		
		
		switch(Kiosk.cmd) {
		
		case "1":
			System.out.println("케이크 선택 ");
			Product q = new Product("케이크", 5500);
			Kiosk.basket4.add(q);
			System.out.println("");
			break;
			
		case "2":
			System.out.println("마카롱 선택");
			Product w = new Product("아메리카노", 6000);
			System.out.println("");
			Kiosk.basket5.add(w);
			break;
			
		case "3":
			System.out.println("바나나 선택");
			Product e = new Product("카페라떼", 2500);
			System.out.println("");
			Kiosk.basket6.add(e);
			break;
			
		case "x":
			System.out.println("이전 메뉴 이동");
			System.out.println("");
			break yy;
			
		}
			}//while
	}
		
	


}